// const arr=[1,2,3,4,5];
// arr.forEach(element => {
//     console.log(element*element);
// });


// function sum(a,b)
// {
//     const total=a+b;
//     return total;
// }

// let total=sum(3,4);
// console.log(total);


function reverseNumber(num)
{
    num=num+"";
   return num.split("").reverse().join();
}

console.log(reverseNumber(32243));

